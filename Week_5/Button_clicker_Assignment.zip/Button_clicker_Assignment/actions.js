function logOut(element) {
    element.innerText = "Logout";
}

function message() {
    alert(`Ninja was liked`)
}


function hide(element) {
    element.remove();
}

