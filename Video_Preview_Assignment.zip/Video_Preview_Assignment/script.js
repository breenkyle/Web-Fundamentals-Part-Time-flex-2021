console.log("page loaded...");

var x = document.getElementById("video");

function playVid(element) {
    x.play("video");
}

function pauseVid(element) {
    x.pause("video");
}